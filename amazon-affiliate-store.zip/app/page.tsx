import Image from "next/image"
import { ProductCard } from "./components/ProductCard"
import { TodaysDeals } from "./components/TodaysDeals"
import { CategorySection } from "./components/CategorySection"
import productsData from "./data/products.json"

export default function Home() {
  return (
    <div className="container mx-auto px-4 py-8">
      <section className="mb-12">
        <div className="relative">
          <Image
            src="/placeholder.svg"
            alt="Promotional Banner"
            width={1200}
            height={400}
            className="rounded-lg shadow-md w-full h-[200px] sm:h-[300px] md:h-[400px] object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black to-transparent opacity-70 rounded-lg"></div>
          <div className="absolute top-1/2 left-4 sm:left-8 transform -translate-y-1/2 text-white">
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-2 sm:mb-4">Amazing Deals</h1>
            <p className="text-sm sm:text-base md:text-xl mb-2 sm:mb-6">
              Discover our curated selection of top products
            </p>
            <button className="btn-primary text-sm sm:text-base">Shop Now</button>
          </div>
        </div>
      </section>

      <TodaysDeals products={productsData.slice(0, 4)} />

      <section className="mb-12">
        <h2 className="text-2xl sm:text-3xl font-bold mb-6 sm:mb-8">Featured Products</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {productsData.slice(0, 8).map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      <CategorySection
        title="Electronics"
        products={productsData.filter((p) => p.category === "electronics").slice(0, 4)}
      />

      <CategorySection
        title="Home & Kitchen"
        products={productsData.filter((p) => p.category === "home-and-kitchen").slice(0, 4)}
      />

      <CategorySection title="Fashion" products={productsData.filter((p) => p.category === "fashion").slice(0, 4)} />
    </div>
  )
}

